/***************************************
Program Name: Lab 10
Author: Robert Elsom
Date: 3/12/2019
Description: Header file for Fibonacci classS
**************************************/

#ifndef FIBONACCI_HPP
#define FIBONACCI_HPP
class Fibonacci	{
public:
	int recursiveCall(int);
	int iterativeCall(int );
	
	
	
};
#endif