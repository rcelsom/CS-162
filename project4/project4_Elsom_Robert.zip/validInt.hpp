/***************************************
Program Name: Project 7
Author: Robert Elsom
Date: 2/21/2019
Descri/ption: Header file for validInt function
**************************************/

#ifndef VALID_INT_HPP
#define VALID_INT_HPP

int validInt(std::string prompt, int lowerLimit, int upperLimit);

#endif