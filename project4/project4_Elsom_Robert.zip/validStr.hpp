/***************************************
Program Name: Project 1
Author: Robert Elsom
Date: 1/10/2019
Description: Header file for validStr function
**************************************/

#ifndef VALID_STR_HPP
#define VALID_STR_HPP

std::string validStr(std::string prompt, int testCase);

#endif