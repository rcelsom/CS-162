/***************************************
Program Name: Lab 2
Author: Robert Elsom
Date: 1/17/2019
Description: Header file for count_letters function 
**************************************/

#ifndef COUNT_LETTERS_HPP
#define COUTNT_LETTERS_HPP

void count_letters(std::ifstream &inputFile, int numOfLetters[]);

#endif
