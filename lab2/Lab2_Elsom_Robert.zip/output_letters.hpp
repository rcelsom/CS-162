/***************************************
Program Name: Lab 2
Author: Robert Elsom
Date: 1/17/2019
Description: Header file for output_letters function 
**************************************/

#ifndef OUTPUT_LETTERS_HPP
#define OUTPUT_LETTERS_HPP

void output_letters( std::ofstream &outputFile, int letterCount[]);

#endif
