/***************************************
Program Name: Lab4
Author: Robert Elsom
Date: 1/26/2019
Description: main function for lab4
**************************************/
#include <iostream>
#include "University.hpp"

int main()	{
	University university;
	university.menu();
	
}