/***************************************
Program Name: Lab 4
Author: Robert Elsom
Date: 1/27/2019
Description: Header file for validDbl function
**************************************/

#ifndef VALID_DBL_HPP
#define VALID_DBL_HPP

double validDbl(std::string prompt, double lowerLimit, double upperLimit);

#endif