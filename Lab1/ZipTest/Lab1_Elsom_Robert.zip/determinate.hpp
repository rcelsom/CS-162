/***************************************
Program Name: Lab 1
Author: Robert Elsom
Date: 1/8/2019
Description: Header file for determinate.cpp
**************************************/
#ifndef DETERMINATE_HPP
#define DETERMINATE_HPP

int determinate(int* a[], int detMatrixSize);

#endif
