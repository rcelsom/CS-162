/***************************************
Program Name: Lab 1
Author: Robert Elsom
Date: 1/8/2019
Description: Header file for readMatrix.cpp
**************************************/
#ifndef READ_MATRIX_HPP
#define READ_MATRIX_HPP

void readMatrix(int* ptrMatrix[], int matrixSize);

#endif
