/***************************************
Program Name: Project 1
Author: Robert Elsom
Date: 1/10/2019
Description: Header file for menu class
**************************************/

#ifndef MENU_HPP
#define MENU_HPP

void menu(int* responseArr, bool repeatMenu = false);

#endif