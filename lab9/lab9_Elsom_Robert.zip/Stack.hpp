/***************************************
Program Name: Lab 9
Author: Robert Elsom
Date: 3/2/2019
Description: Header file for Stack function
**************************************/

#ifndef STACK_HPP
#define STACK_HPP

#include <string>

std::string Stack(std::string startWord);

#endif