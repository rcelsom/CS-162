/***************************************
Program Name: Project2
Author: Robert Elsom
Date: 1/22/2019
Description: main function for project 2.
			Creates a game object and starts the game
			by calling the start() function to get the start menu
**************************************/
#include "Zoo.hpp"


int main()	{
	Zoo zoo;
	zoo.start();
	
}